﻿using StorageMaster.Entities.Products;
using StorageMaster.Entities.Vehicles;
using System;

namespace StorageMaster
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
